YouTube Subtitle Analytics 
Scrape, analyze and sort YouTube video subtitles with Python.

Created on January 16, 2023.

Instructions:

1. Copy a YouTube video ID from a URL.
2. Edit YouTube_Captions.py and paste the video ID (11 >> id = '6S6sMYtHeUc').
3. Run YouTube_Captions.py.
4. Copy subtitles.txt to Analytics folder.
5. Run Caption_Analytics.py.
6. Open analytics.txt and popular.txt.


